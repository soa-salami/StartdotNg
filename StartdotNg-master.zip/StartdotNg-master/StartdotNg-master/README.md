This repository is on the second task of the StartdotNg programme. Here, I created a HTML document of my Curriculum Vitae with image attached from cloudinary. Below are links to Twitter and Lucid posts. 

Link to twitter post: https://twitter.com/Iam_Salheed/status/1164794924300005379?s=20


Link to Lucid post: https://lucid.blog/salheed.mide08/post/1566542804

